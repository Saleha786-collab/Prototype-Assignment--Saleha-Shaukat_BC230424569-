from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from model import db, User, SupportTicket  # Corrected model imports
from datetime import datetime

# Initialize Flask app
app = Flask(__name__)

# Configure database URI and other settings
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Saleha%40786@localhost/restaurant_chatbot'  # Ensure correct password
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database and migration tool
db.init_app(app)
migrate = Migrate(app, db)

# Webhook route to handle requests from Dialogflow or other services
@app.route('/webhook', methods=['POST'])
def webhook():
   req = request.get_json(force=True)  # Parse JSON request

   # Extract the intent from the request
   intent = req['queryResult']['intent']['displayName']

   # Handle different intents
   if intent == 'Technical Support Intent':
       return Technical_Support(req)
   elif intent == 'Issue Described Intent':
       return Issue_Described(req)
   elif intent == 'Issue Resolved Intent':
       return Issue_Resolved(req)
   elif intent == 'Issue Not Resolved Intent':
       return Issue_Not_Resolved(req)
   elif intent == 'Email Capture':
       return check_ticket_creation(req)
   elif intent == 'Default Welcome Intent':
       return Default_Welcome(req)
   elif intent == 'Invalid Input':
       return invalid_input(req)
   elif intent == 'Multiple Intents Detected':
       return Multiple_Intents_Detected(req)
   elif intent == 'Ending Conversation Intent':
       return Closing_Conversation()

   # Default response if intent is not recognized
   return fallback_response()

# Intent Handlers
def Default_Welcome(req):
   response = "Hello! Welcome to the Restaurant. How can I assist you today?"
   return jsonify({'fulfillmentText': response})

def fallback_response():
   response = "I’m sorry, I didn’t quite understand. Could you please rephrase your question?"
   return jsonify({'fulfillmentText': response})

def Closing_Conversation():
   response = "Thank you for chatting with us. Have a great day!"
   return jsonify({'fulfillmentText': response})

def Technical_Support(req):
   response = 'Could you please describe the issue you are facing?'
   return jsonify({'fulfillmentText': response})

def Issue_Described(req):
   issue = req['queryResult']['parameters'].get('issue')
   response = "I’m sorry to hear that. Let’s try some basic troubleshooting steps. Have you tried resetting the device by holding the power button for 10 seconds?"
   return jsonify({'fulfillmentText': response})

def Issue_Resolved(req):
   response = "Glad to hear! Anything else I can help with?"
   return jsonify({'fulfillmentText': response})

def Issue_Not_Resolved(req):
   response = "I’ll create a support ticket for further assistance. Can you confirm your email address and preferred contact method?"
   return jsonify({'fulfillmentText': response})

def check_ticket_creation(req):
   # Optional parameters for name and email
   email = req['queryResult']['parameters'].get('email')
   name = req['queryResult']['parameters'].get('name', 'Guest User')  # Default to "Guest User" if name is not provided

   # If email is not provided, create a generic support ticket
   if not email:
       email = "guest@example.com"  # Using a default email for guests

   # Check if the user already exists
   user = User.query.filter_by(email=email).first()

   if not user:
       # Create a new user if they don't exist
       user = User(name=name, email=email)
       try:
           db.session.add(user)
           db.session.commit()
       except Exception as e:
           db.session.rollback()  # Rollback in case of error
           return jsonify({'fulfillmentText': f"Error occurred while creating user: {e}"})

   # Create a support ticket for the user (you can use the description or use a generic issue)
   issue_description = req['queryResult']['parameters'].get('issue', 'Technical issue reported by user')
   new_ticket = SupportTicket(user_id=user.user_id, issue_description=issue_description)
   try:
       db.session.add(new_ticket)
       db.session.commit()
   except Exception as e:
       db.session.rollback()  # Rollback if error occurs
       return jsonify({'fulfillmentText': f"Error occurred while creating ticket: {e}"})

   return jsonify({'fulfillmentText': "Your support ticket has been created successfully. Our team will get back to you shortly."})

def invalid_input(req):
   response = "Sorry, that doesn’t seem to be a valid order number. Could you check and try again?"
   return jsonify({'fulfillmentText': response})

def Multiple_Intents_Detected(req):
   response = "I see you’re asking about multiple things. Which one would you like to start with?"
   return jsonify({'fulfillmentText': response})

# Run the Flask app
if __name__ == '__main__':
   app.run(debug=True)
