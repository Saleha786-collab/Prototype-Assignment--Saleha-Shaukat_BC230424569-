from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Initialize the Flask app and SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Saleha%40786@localhost/restaurant_chatbot'  # Ensure correct password
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# User Model
class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    phone_number = db.Column(db.String(20))
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationship
    tickets = db.relationship('SupportTicket', backref='user', lazy=True)
    orders = db.relationship('Order', backref='user', lazy=True)
    inquiries = db.relationship('ProductInquiry', backref='user', lazy=True)

    def __repr__(self):
        return f'<User {self.name}>'

# SupportTicket Model
class SupportTicket(db.Model):
    __tablename__ = 'support_tickets'
    ticket_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    issue_description = db.Column(db.Text, nullable=False)
    status = db.Column(db.Enum('open', 'closed', 'pending'), default='open')
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    resolved_at = db.Column(db.TIMESTAMP)
    updated_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<SupportTicket {self.ticket_id}>'

# Product Model
class Product(db.Model):
    __tablename__ = 'products'
    product_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Numeric(10, 2))
    stock = db.Column(db.Integer)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow)

    # Relationship
    inquiries = db.relationship('ProductInquiry', backref='product', lazy=True)
    order_items = db.relationship('OrderItem', backref='product', lazy=True)

    def __repr__(self):
        return f'<Product {self.name}>'

# Order Model
class Order(db.Model):
    __tablename__ = 'orders'
    order_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    order_status = db.Column(db.Enum('pending', 'shipped', 'delivered'), default='pending')
    order_date = db.Column(db.TIMESTAMP, default=datetime.utcnow)
    delivery_date = db.Column(db.TIMESTAMP)

    # Relationship
    items = db.relationship('OrderItem', backref='order', lazy=True)

    def __repr__(self):
        return f'<Order {self.order_id}>'

# OrderItem Model
class OrderItem(db.Model):
    __tablename__ = 'order_items'
    order_item_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.order_id'))
    product_id = db.Column(db.Integer, db.ForeignKey('products.product_id'))
    quantity = db.Column(db.Integer)

    def __repr__(self):
        return f'<OrderItem {self.order_item_id}>'

# ProductInquiry Model
class ProductInquiry(db.Model):
    __tablename__ = 'product_inquiries'
    inquiry_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    product_id = db.Column(db.Integer, db.ForeignKey('products.product_id'))
    inquiry_text = db.Column(db.Text, nullable=False)
    response_text = db.Column(db.Text)
    inquiry_date = db.Column(db.TIMESTAMP, default=datetime.utcnow)

    def __repr__(self):
        return f'<ProductInquiry {self.inquiry_id}>'

# Initialize the database (Run this once to create the tables)
def init_db():
    with app.app_context():
        db.create_all()

# For debugging purposes (run this file directly)
if __name__ == '__main__':
    app.run(debug=True)
