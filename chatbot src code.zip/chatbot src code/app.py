import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError  # For handling database errors
from sqlalchemy import text  # For raw SQL queries (if needed)
from model import db, User, SupportTicket, Product, Order, OrderItem, ProductInquiry
from form import RegistrationForm, LoginForm, Accountform
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, login_user, current_user, logout_user, login_required

# Configure logging
if os.getenv("FLASK_ENV") == "development":
    logging.basicConfig(level=logging.DEBUG)
else:
    logging.basicConfig(level=logging.WARNING)

# Initialize Flask app
app = Flask(__name__)

# Configure the database URI using environment variables
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'mysql+pymysql://root:Saleha%40786@localhost/db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'defaultsecretkey')

# Initialize the database and migration
db.init_app(app)
migrate = Migrate(app, db)

# Initialize other components
bcrypt = Bcrypt(app)

# Initialize Login Manager
login_manager = LoginManager(app)
login_manager.login_view = "login"

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except (ValueError, TypeError):
        return None

# Routes for user registration and login
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_pwd = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_pwd)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data): 
            login_user(user, form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/account', methods=['GET', 'POST'])
@login_required
def account():
    form = Accountform()
    if form.validate_on_submit():
        current_user.username = form.username.data
        current_user.email = form.email.data
        db.session.commit()
        flash('Your Account has been updated')
        return redirect(url_for('account'))
    elif request.method == 'GET':
        form.username.data = current_user.username
        form.email.data = current_user.email
    
    return render_template('account.html', title='Account', form=form)

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

# Dialogflow Webhook Route - Protected with login_required
@app.route('/webhook', methods=['POST'])
def webhook():
    req = request.get_json(force=True)
    logging.debug(f"Received Request: {req}")

    # Handle different intents
    intent = req['queryResult']['intent']['displayName']
    if intent == 'Technical Support Intent':
        return Technical_Support(req)
    elif intent == 'Issue Described Intent':
        return Issue_Described(req)
    elif intent == 'Issue Resolved Intent':
        return Issue_Resolved(req)
    elif intent == 'Issue Not Resolved Intent':
        return Issue_Not_Resolved(req)
    elif intent == 'Email Capture':
        return check_ticket_creation(req)
    elif intent == 'Default Welcome Intent':
        return Default_Welcome(req)
    elif intent == 'Invalid Input':
        return invalid_input(req)
    elif intent == 'Multiple Intents Detected':
        return Multiple_Intents_Detected(req)
    elif intent == 'Ending Conversation Intent':
        return Closing_Conversation()
    elif intent == 'Order Status Intent':
        return handle_order_status(req)

    return fallback_response()

def Default_Welcome(req):
    if current_user.is_authenticated:
        response = f"Hello {current_user.username}! Welcome to the Restaurant. How can I assist you today?"
    else:
        response = "Hello! Welcome to the Restaurant. How can I assist you today?"
    return jsonify({'fulfillmentText': response})

def handle_order_status(req):
    try:
        # Log the entire incoming request to check the parameters being sent
        logging.debug(f"Full Request: {req}")
        
        # Extract parameters safely
        parameters = req.get('queryResult', {}).get('parameters', {})
        order_id = parameters.get('order_id')

        # Log the extracted order_id to see if it's being passed correctly
        logging.debug(f"Extracted Order ID: {order_id}")

        if not order_id:
            # If order_id is missing, return a proper response
            return jsonify({'fulfillmentText': "Please provide an Order ID."})

        try:
            # Convert order_id to integer and log the conversion step
            order_id = int(order_id)  
            logging.debug(f"Order ID after conversion: {order_id}")
        except ValueError:
            return jsonify({'fulfillmentText': "Invalid Order ID format. Please provide a valid number."})

        # Query the order from the database
        order = Order.query.get(order_id)
        logging.debug(f"Order found in database: {order}")

        if order:
            delivery_date = order.delivery_date.strftime("%d %B %Y") if order.delivery_date else "not set"
            return jsonify({
                'fulfillmentText': f"Order #{order_id}\nStatus: {order.order_status}\nDelivery: {delivery_date} Would you like anything else?"
            })
        else:
            return jsonify({'fulfillmentText': f"No order found with ID {order_id}"})

    except Exception as e:
        # Log the error to troubleshoot
        logging.error(f"Error processing order status: {str(e)}")
        return jsonify({'fulfillmentText': "System error. Contact support."})



def fallback_response():
    response = "I'm sorry, I didn't quite understand. Could you please rephrase your question?"
    return jsonify({'fulfillmentText': response})

def Closing_Conversation():
    response = "Thank you for chatting with us. Have a great day!"
    return jsonify({'fulfillmentText': response})

def Technical_Support(req):
    response = 'Could you please describe the issue you are facing?'
    return jsonify({'fulfillmentText': response})

def Issue_Described(req):
    issue = req['queryResult']['parameters'].get('issue')
    response = "I'm sorry to hear that. Let's try some basic troubleshooting steps. Have you tried resetting the device by holding the power button for 10 seconds?"
    return jsonify({'fulfillmentText': response})

def Issue_Resolved(req):
    response = "Glad to hear! Anything else I can help with?"
    return jsonify({'fulfillmentText': response})

def Issue_Not_Resolved(req):
    response = "I'll create a support ticket for further assistance. Can you confirm your email address and preferred contact method?"
    return jsonify({'fulfillmentText': response})

def check_ticket_creation(req):
    try:
        if current_user.is_authenticated:
            email = current_user.email
            name = current_user.username
        else:
            email = req['queryResult']['parameters'].get('email', 'unknown@example.com')
            name = req['queryResult']['parameters'].get('name', 'Guest')

        issue_description = req['queryResult']['parameters'].get('issue', 'Technical issue reported by user')
        logging.debug(f"Creating support ticket for issue: {issue_description}")

        new_ticket = SupportTicket(user_id=current_user.user_id if current_user.is_authenticated else None, issue_description=issue_description, email=email)
        db.session.add(new_ticket)
        db.session.commit()
        logging.debug(f"Ticket created successfully with ID: {new_ticket.ticket_id}")
        
        return jsonify({'fulfillmentText': "Your support ticket has been created successfully. Our team will get back to you shortly."})

    except Exception as e:
        db.session.rollback()
        logging.error(f"Error while creating ticket: {e}")
        return jsonify({'fulfillmentText': f"Error occurred while creating ticket: {e}"})

def invalid_input(req):
    response = "Sorry, that doesn't seem to be a valid order number. Could you check and try again?"
    return jsonify({'fulfillmentText': response})

def Multiple_Intents_Detected(req):
    response = "I see you're asking about multiple things. Which one would you like to start with?"
    return jsonify({'fulfillmentText': response})

def init_db():
    with app.app_context():
        db.create_all()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
